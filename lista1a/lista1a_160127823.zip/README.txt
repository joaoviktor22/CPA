Código feito no CLion no Windows usando Compilador MinGW-w64
Usando C++14.

Foi testado no Linux usando:
g++ -o q1 q1_lista1a.cpp
./q1

g++ -o q2 q2_lista1a.cpp
./q2

g++ -o q3 q3_lista1a.cpp
./q3